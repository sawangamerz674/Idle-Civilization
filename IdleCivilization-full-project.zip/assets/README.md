# Assets

Every file here was exported from the game itself (its own renderers and synthesizer), so they match what players see and hear. `manifest.json` lists them all.

| Folder | Contents |
|---|---|
| `backgrounds/<era>/` | Empty-world scene for each of the 5 eras: `background-1920x1080.png`, `background-960x540.png`, `thumb-480x270.png` |
| `buildings/<era>/` | One transparent PNG per building (25 total), named by building id (e.g. `farm.png`, `castle.png`) |
| `citizens/idle/` | Standing NPC per era (`<era>.png`) and an 8-frame strip (`<era>_strip8.png`) |
| `citizens/working/` | 8-frame work-cycle strips per era and tool: hoe, axe, pickaxe, hammer, wrench, book, coins |
| `citizens/animations/` | 8-frame walk-cycle strips per era (150x190 per frame) |
| `resources/<id>/` | `icon.svg`, `icon-256.png`, `icon-64.png` for food, wood, stone, metal, coins, energy, science |
| `effects/` | `glow`, `sparkle`, `star`, `ring`, `smoke`, `confetti`, plus `coin-spin` and `burst` strips |
| `icons/` | Game icon (`icon.svg`, PNGs 32-512, `apple-touch-icon.png`, `icon.webmanifest`) and `ui/` (34 UI icons as SVG) |
| `audio/sounds/` | 11 sound effects (click, tick, error, pop, build, upgrade, research, reward, achievement, era, prestige) as `.ogg` and `.mp3` |
| `audio/music/` | One 40-second theme per era as `.ogg` and `.mp3` |
| `fonts/` | Inter Regular, Bold and ExtraBold (SIL Open Font License; see `Inter-LICENSE.txt`) |

## How the game uses them

The game draws its scenes and plays its sound live in code, so it never depends on these files and loads quickly. The files are for store pages, marketing, and for artists or musicians who want to replace parts of the art or audio. Folder and file names follow the era ids in `data/eras.json` (with `_` shown as `-`) and the building ids in `data/buildings.json`.
